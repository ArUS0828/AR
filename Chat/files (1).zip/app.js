/* =========================================================
   CONFIG — edit these two things before using the app
   ========================================================= */

// 1. Paste your deployed Google Apps Script Web App URL here
const APPS_SCRIPT_URL = "PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE";

// 2. Set the shared "front door" passphrase (anyone entering the
//    site needs this before they even see the login screen).
//    This check happens in the browser, so it's a light gate —
//    not bank-level security — good enough to keep strangers out.
const LOCK_PASSPHRASE = "ourplace";

/* ========================================================= */

const POLL_INTERVAL_MS = 4000;

let currentUser = null;
let otherUser = null;
let lastMessageId = 0;
let pollTimer = null;

const el = (id) => document.getElementById(id);

/* ---------- Lock screen ---------- */

el('lockSubmit').addEventListener('click', tryUnlock);
el('lockPassword').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') tryUnlock();
});

function tryUnlock() {
  const val = el('lockPassword').value;
  if (val === LOCK_PASSPHRASE) {
    el('lockScreen').classList.add('d-none');
    el('loginScreen').classList.remove('d-none');
  } else {
    el('lockError').textContent = "that's not it — try again";
    el('lockPassword').value = '';
  }
}

/* ---------- User select / login ---------- */

document.querySelectorAll('.user-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.user-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    el('usernameField').value = btn.dataset.user;
  });
});

el('loginSubmit').addEventListener('click', tryLogin);
el('userPassword').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') tryLogin();
});

async function tryLogin() {
  const username = el('usernameField').value;
  const password = el('userPassword').value;
  if (!password) return;

  el('loginSubmit').disabled = true;
  el('loginError').textContent = '';

  try {
    const url = `${APPS_SCRIPT_URL}?action=login&username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
    const res = await fetch(url);
    const data = await res.json();

    if (data.status === 'success') {
      currentUser = data.user;
      otherUser = currentUser === 'User1' ? 'User2' : 'User1';
      sessionStorage.setItem('chatUser', currentUser);
      enterChat();
    } else {
      el('loginError').textContent = data.message || 'wrong password';
    }
  } catch (err) {
    el('loginError').textContent = 'could not reach the server — check the setup';
  } finally {
    el('loginSubmit').disabled = false;
  }
}

/* ---------- Chat screen ---------- */

function enterChat() {
  el('loginScreen').classList.add('d-none');
  el('chatScreen').classList.remove('d-none');
  el('meLabel').textContent = currentUser;
  el('statusDot').classList.add('online');
  loadMessages(true);
  pollTimer = setInterval(() => loadMessages(false), POLL_INTERVAL_MS);
}

el('logoutBtn').addEventListener('click', () => {
  clearInterval(pollTimer);
  sessionStorage.removeItem('chatUser');
  currentUser = null;
  lastMessageId = 0;
  el('messageList').innerHTML = '';
  el('chatScreen').classList.add('d-none');
  el('loginScreen').classList.remove('d-none');
  el('userPassword').value = '';
});

el('composerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = el('messageInput');
  const text = input.value.trim();
  if (!text) return;

  input.value = '';
  el('sendBtn').disabled = true;

  // optimistic render
  appendMessage({ sender: currentUser, message: text, timestamp: new Date(), id: 'temp-' + Date.now() }, true);

  try {
    const url = `${APPS_SCRIPT_URL}?action=send&sender=${encodeURIComponent(currentUser)}&message=${encodeURIComponent(text)}`;
    await fetch(url);
    await loadMessages(false);
  } catch (err) {
    // message stays visible locally even if the network hiccups
  } finally {
    el('sendBtn').disabled = false;
    input.focus();
  }
});

async function loadMessages(isInitialLoad) {
  try {
    const url = `${APPS_SCRIPT_URL}?action=fetch&since=${lastMessageId}`;
    const res = await fetch(url);
    const data = await res.json();

    if (data.status !== 'success') return;

    if (isInitialLoad) el('messageList').innerHTML = '';

    if (isInitialLoad && data.messages.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'msg-empty';
      empty.textContent = 'no messages yet — say hi';
      el('messageList').appendChild(empty);
    }

    data.messages.forEach((m) => {
      const emptyState = el('messageList').querySelector('.msg-empty');
      if (emptyState) emptyState.remove();
      appendMessage(m, false);
      lastMessageId = Math.max(lastMessageId, m.id);
    });

    el('statusDot').classList.add('online');
  } catch (err) {
    el('statusDot').classList.remove('online');
  }
}

function appendMessage(m, isOptimistic) {
  const row = document.createElement('div');
  row.className = `msg-row ${m.sender === currentUser ? 'mine' : 'theirs'}`;
  if (isOptimistic) row.dataset.temp = 'true';

  const bubble = document.createElement('div');
  bubble.className = 'msg-bubble';
  bubble.textContent = m.message;

  const meta = document.createElement('div');
  meta.className = 'msg-meta';
  const time = new Date(m.timestamp);
  meta.textContent = isNaN(time) ? '' : time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  row.appendChild(bubble);
  row.appendChild(meta);
  el('messageList').appendChild(row);
  el('messageList').scrollTop = el('messageList').scrollHeight;
}

/* ---------- Resume session on refresh ---------- */

window.addEventListener('load', () => {
  const saved = sessionStorage.getItem('chatUser');
  if (saved) {
    // still require the front-door passphrase again for safety
  }
});
